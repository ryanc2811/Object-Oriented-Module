﻿using System;
using System.Collections.Generic;
using System.Text;

namespace COMP3304Session1
{
    public interface INotes
    {
        void AddNoteData(int index);
        void RemoveNoteData(int index);
    }
}
